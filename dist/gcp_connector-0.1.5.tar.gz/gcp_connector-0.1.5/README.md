# gcp_connector

Uso de conexion a proyectos de GCP. Para conexion y extraccion de informacion BigQuery. Conexion y extraccion de informacion de Google Sheets.

Requiere envio de Scopes de uso, y credenciales de GCP en formato Base64.